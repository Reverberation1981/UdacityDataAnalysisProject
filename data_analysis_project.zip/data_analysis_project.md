

```python
import pandas as pd

# Importing the data set that I chose, which was the tmdb movies data set
movies_df = pd.read_csv('tmdb-movies.csv')
```

# tmdb-movies data set


```python
# Seeing what the data set looks like
movies_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>imdb_id</th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>original_title</th>
      <th>cast</th>
      <th>homepage</th>
      <th>director</th>
      <th>tagline</th>
      <th>...</th>
      <th>overview</th>
      <th>runtime</th>
      <th>genres</th>
      <th>production_companies</th>
      <th>release_date</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>budget_adj</th>
      <th>revenue_adj</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>135397</td>
      <td>tt0369610</td>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Jurassic World</td>
      <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
      <td>http://www.jurassicworld.com/</td>
      <td>Colin Trevorrow</td>
      <td>The park is open.</td>
      <td>...</td>
      <td>Twenty-two years after the events of Jurassic ...</td>
      <td>124</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Universal Studios|Amblin Entertainment|Legenda...</td>
      <td>6/9/15</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>1.379999e+08</td>
      <td>1.392446e+09</td>
    </tr>
    <tr>
      <th>1</th>
      <td>76341</td>
      <td>tt1392190</td>
      <td>28.419936</td>
      <td>150000000</td>
      <td>378436354</td>
      <td>Mad Max: Fury Road</td>
      <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
      <td>http://www.madmaxmovie.com/</td>
      <td>George Miller</td>
      <td>What a Lovely Day.</td>
      <td>...</td>
      <td>An apocalyptic story set in the furthest reach...</td>
      <td>120</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
      <td>5/13/15</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
      <td>1.379999e+08</td>
      <td>3.481613e+08</td>
    </tr>
    <tr>
      <th>2</th>
      <td>262500</td>
      <td>tt2908446</td>
      <td>13.112507</td>
      <td>110000000</td>
      <td>295238201</td>
      <td>Insurgent</td>
      <td>Shailene Woodley|Theo James|Kate Winslet|Ansel...</td>
      <td>http://www.thedivergentseries.movie/#insurgent</td>
      <td>Robert Schwentke</td>
      <td>One Choice Can Destroy You</td>
      <td>...</td>
      <td>Beatrice Prior must confront her inner demons ...</td>
      <td>119</td>
      <td>Adventure|Science Fiction|Thriller</td>
      <td>Summit Entertainment|Mandeville Films|Red Wago...</td>
      <td>3/18/15</td>
      <td>2480</td>
      <td>6.3</td>
      <td>2015</td>
      <td>1.012000e+08</td>
      <td>2.716190e+08</td>
    </tr>
    <tr>
      <th>3</th>
      <td>140607</td>
      <td>tt2488496</td>
      <td>11.173104</td>
      <td>200000000</td>
      <td>2068178225</td>
      <td>Star Wars: The Force Awakens</td>
      <td>Harrison Ford|Mark Hamill|Carrie Fisher|Adam D...</td>
      <td>http://www.starwars.com/films/star-wars-episod...</td>
      <td>J.J. Abrams</td>
      <td>Every generation has a story.</td>
      <td>...</td>
      <td>Thirty years after defeating the Galactic Empi...</td>
      <td>136</td>
      <td>Action|Adventure|Science Fiction|Fantasy</td>
      <td>Lucasfilm|Truenorth Productions|Bad Robot</td>
      <td>12/15/15</td>
      <td>5292</td>
      <td>7.5</td>
      <td>2015</td>
      <td>1.839999e+08</td>
      <td>1.902723e+09</td>
    </tr>
    <tr>
      <th>4</th>
      <td>168259</td>
      <td>tt2820852</td>
      <td>9.335014</td>
      <td>190000000</td>
      <td>1506249360</td>
      <td>Furious 7</td>
      <td>Vin Diesel|Paul Walker|Jason Statham|Michelle ...</td>
      <td>http://www.furious7.com/</td>
      <td>James Wan</td>
      <td>Vengeance Hits Home</td>
      <td>...</td>
      <td>Deckard Shaw seeks revenge against Dominic Tor...</td>
      <td>137</td>
      <td>Action|Crime|Thriller</td>
      <td>Universal Pictures|Original Film|Media Rights ...</td>
      <td>4/1/15</td>
      <td>2947</td>
      <td>7.3</td>
      <td>2015</td>
      <td>1.747999e+08</td>
      <td>1.385749e+09</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>



# How does the budget of a movie correlate to its popularity? How does the popularity of a movie influence its revenue?

# The three variables I am exploring are a movie's Budget, Popularity, and Revenue. I want to see if the variables have strong relationships with one another.


```python
category_list = list(movies_df.columns.values)

for i in range(0, len(movies_df)):
    for category in category_list:
        if movies_df.iloc[i][category] == "0" or movies_df.iloc[i][category] == "":
            print(movies_df.iloc[i][category])
```


```python

def data_loop(category, minimum):
    categorylist = []
    count = 0
    for i in range(1, len(movies_df)):
        if movies_df.iloc[i][category] < minimum:
            print("Title: " + str(movies_df.iloc[i]['original_title']))
            print("Popularity: " + str(movies_df.iloc[i]['popularity']))
            print("Budget: " + str(movies_df.iloc[i]['budget']))
            print("Revenue: " + str(movies_df.iloc[i]['revenue']))
            count += 1
    print(category + ": " + str(count))
    return category_list

popularity_list = data_loop("popularity", 0.01)
budget_list = data_loop("budget", 1000)

```

    popularity: 0
    Title: Jenny's Wedding
    Popularity: 0.8611790000000001
    Budget: 0
    Revenue: 0
    Title: The End of the Tour
    Popularity: 0.8369409999999989
    Budget: 0
    Revenue: 3002884
    Title: Open Season: Scared Silly
    Popularity: 0.7739090000000001
    Budget: 0
    Revenue: 0
    Title: Barbie in Princess Power
    Popularity: 0.7141310000000001
    Budget: 0
    Revenue: 0
    Title: Air
    Popularity: 0.638556999999999
    Budget: 0
    Revenue: 0
    Title: Extinction
    Popularity: 0.606113
    Budget: 0
    Revenue: 0
    Title: Beyond the Mask
    Popularity: 0.514735
    Budget: 0
    Revenue: 1236094
    Title: Hidden
    Popularity: 0.5024890000000001
    Budget: 0
    Revenue: 0
    Title: Spare Parts
    Popularity: 0.475473
    Budget: 0
    Revenue: 0
    Title: Cartel Land
    Popularity: 0.471393
    Budget: 0
    Revenue: 0
    Title: The Boy
    Popularity: 0.443525
    Budget: 0
    Revenue: 0
    Title: The Final Girls
    Popularity: 0.441882
    Budget: 0
    Revenue: 0
    Title: Battle For SkyArk
    Popularity: 0.43708800000000003
    Budget: 0
    Revenue: 0
    Title: 12 Gifts of Christmas
    Popularity: 0.417191
    Budget: 0
    Revenue: 0
    Title: Born to Be Blue
    Popularity: 0.396791
    Budget: 0
    Revenue: 830129
    Title: The Intruders
    Popularity: 0.383183
    Budget: 0
    Revenue: 0
    Title: Navy Seals vs. Zombies
    Popularity: 0.37668
    Budget: 0
    Revenue: 0
    Title: Uncanny
    Popularity: 0.371145
    Budget: 0
    Revenue: 0
    Title: Going Clear: Scientology and the Prison of Belief
    Popularity: 0.357614
    Budget: 0
    Revenue: 0
    Title: Barbie in Rock 'N Royals
    Popularity: 0.350858
    Budget: 0
    Revenue: 0
    Title: Minions: The Competition
    Popularity: 0.344994
    Budget: 0
    Revenue: 0
    Title: Babysitter's Black Book
    Popularity: 0.33929699999999996
    Budget: 0
    Revenue: 0
    Title: Freaks of Nature
    Popularity: 0.330968
    Budget: 0
    Revenue: 70958
    Title: Entertainment
    Popularity: 0.324666
    Budget: 0
    Revenue: 0
    Title: Bessie
    Popularity: 0.322653
    Budget: 0
    Revenue: 0
    Title: Oddball
    Popularity: 0.315196
    Budget: 0
    Revenue: 0
    Title: Christmas Eve
    Popularity: 0.30591599999999997
    Budget: 0
    Revenue: 0
    Title: Hitting the Apex
    Popularity: 0.198522
    Budget: 0
    Revenue: 0
    Title: Backcountry
    Popularity: 0.29042399999999996
    Budget: 0
    Revenue: 0
    Title: Nina Forever
    Popularity: 0.277844
    Budget: 0
    Revenue: 0
    Title: Digging for Fire
    Popularity: 0.171829
    Budget: 0
    Revenue: 0
    Title: Already Tomorrow in Hong Kong
    Popularity: 0.255458
    Budget: 0
    Revenue: 0
    Title: The Driftless Area
    Popularity: 0.24660900000000002
    Budget: 0
    Revenue: 0
    Title: Teen Beach 2
    Popularity: 0.243691
    Budget: 0
    Revenue: 0
    Title: Close Range
    Popularity: 0.23949600000000001
    Budget: 0
    Revenue: 0
    Title: A Christmas Detour
    Popularity: 0.231337
    Budget: 0
    Revenue: 0
    Title: People, Places, Things
    Popularity: 0.222636
    Budget: 0
    Revenue: 0
    Title: Being Charlie
    Popularity: 0.21960300000000002
    Budget: 0
    Revenue: 30400
    Title: Last Cab to Darwin
    Popularity: 0.355707
    Budget: 0
    Revenue: 0
    Title: Muck
    Popularity: 0.214563
    Budget: 0
    Revenue: 0
    Title: Taylor Swift: The 1989 World Tour - Live
    Popularity: 0.209036
    Budget: 0
    Revenue: 0
    Title: Deep Web
    Popularity: 0.20713299999999998
    Budget: 0
    Revenue: 0
    Title: Nasty Baby
    Popularity: 0.29922600000000005
    Budget: 0
    Revenue: 0
    Title: The Quiet Hour
    Popularity: 0.195324
    Budget: 0
    Revenue: 0
    Title: Listening
    Popularity: 0.19254000000000002
    Budget: 0
    Revenue: 0
    Title: The Condemned 2
    Popularity: 0.270408
    Budget: 0
    Revenue: 0
    Title: Janis: Little Girl Blue
    Popularity: 0.162526
    Budget: 0
    Revenue: 0
    Title: Amy Schumer: Live at the Apollo
    Popularity: 0.157172
    Budget: 0
    Revenue: 0
    Title: Keith Richards: Under the Influence
    Popularity: 0.150713
    Budget: 0
    Revenue: 0
    Title: Strange Blood
    Popularity: 0.145945
    Budget: 0
    Revenue: 0
    Title: Chloe and Theo
    Popularity: 0.143703
    Budget: 0
    Revenue: 0
    Title: Stockholm, Pennsylvania
    Popularity: 0.139356
    Budget: 0
    Revenue: 0
    Title: The True Cost
    Popularity: 0.137772
    Budget: 0
    Revenue: 0
    Title: Finders Keepers
    Popularity: 0.135074
    Budget: 0
    Revenue: 0
    Title: Private Number
    Popularity: 0.127432
    Budget: 0
    Revenue: 0
    Title: Hitchcock/Truffaut
    Popularity: 0.124481
    Budget: 0
    Revenue: 0
    Title: Bloodsucking Bastards
    Popularity: 0.11095999999999999
    Budget: 0
    Revenue: 0
    Title: Listen to Me Marlon
    Popularity: 0.10968900000000001
    Budget: 0
    Revenue: 0
    Title: Big Sky
    Popularity: 0.10675699999999999
    Budget: 0
    Revenue: 0
    Title: Doctor Who: The Husbands of River Song
    Popularity: 0.068741
    Budget: 0
    Revenue: 0
    Title: Brothers
    Popularity: 0.099678
    Budget: 0
    Revenue: 0
    Title: Naomi and Ely's No Kiss List
    Popularity: 0.096624
    Budget: 0
    Revenue: 0
    Title: The Chosen
    Popularity: 0.100069
    Budget: 0
    Revenue: 0
    Title: Harry Price: Ghost Hunter
    Popularity: 0.088764
    Budget: 0
    Revenue: 0
    Title: The Wolfpack
    Popularity: 0.081956
    Budget: 0
    Revenue: 1301696
    Title: Requiem for the American Dream
    Popularity: 0.0807539999999999
    Budget: 0
    Revenue: 44695
    Title: Welcome to Leith
    Popularity: 0.077252
    Budget: 0
    Revenue: 0
    Title: The Hunting Ground
    Popularity: 0.06253600000000001
    Budget: 0
    Revenue: 0
    Title: Submerged
    Popularity: 0.0552419999999999
    Budget: 0
    Revenue: 0
    Title: Deep Dark
    Popularity: 0.028725
    Budget: 0
    Revenue: 0
    Title: Star Wars: TIE Fighter
    Popularity: 0.047256
    Budget: 0
    Revenue: 0
    Title: The Subjects
    Popularity: 0.037487
    Budget: 0
    Revenue: 0
    Title: Twinsters
    Popularity: 0.0345339999999999
    Budget: 0
    Revenue: 0
    Title: The Suicide Theory
    Popularity: 0.030005
    Budget: 0
    Revenue: 0
    Title: The Gamechangers
    Popularity: 0.025252
    Budget: 0
    Revenue: 0
    Title: A Ballerina's Tale
    Popularity: 0.019133
    Budget: 0
    Revenue: 0
    Title: Meet the Patels
    Popularity: 0.014647
    Budget: 0
    Revenue: 0
    Title: How to Make Love Like an Englishman
    Popularity: 0.894732
    Budget: 0
    Revenue: 0
    Title: The Nut Job
    Popularity: 0.833734
    Budget: 0
    Revenue: 0
    Title: Before We Go
    Popularity: 0.760779
    Budget: 0
    Revenue: 37151
    Title: Jackie & Ryan
    Popularity: 0.704138
    Budget: 0
    Revenue: 0
    Title: What We Do in the Shadows
    Popularity: 0.622166
    Budget: 0
    Revenue: 0
    Title: Hellion
    Popularity: 0.593065
    Budget: 0
    Revenue: 0
    Title: Paper Planes
    Popularity: 0.5247649999999989
    Budget: 0
    Revenue: 0
    Title: Citizenfour
    Popularity: 0.512588
    Budget: 0
    Revenue: 0
    Title: The Town that Dreaded Sundown
    Popularity: 0.498787
    Budget: 0
    Revenue: 0
    Title: The Disappearance of Eleanor Rigby: Them
    Popularity: 0.472242
    Budget: 0
    Revenue: 985007
    Title: Premature
    Popularity: 0.465438
    Budget: 0
    Revenue: 0
    Title: Love Is Strange
    Popularity: 0.451125
    Budget: 0
    Revenue: 2262223
    Title: The Disappearance of Eleanor Rigby: Her
    Popularity: 0.42760200000000004
    Budget: 0
    Revenue: 0
    Title: Mercenaries
    Popularity: 0.41329499999999997
    Budget: 0
    Revenue: 0
    Title: Lost After Dark
    Popularity: 0.39199
    Budget: 0
    Revenue: 0
    Title: Sleeping Beauty
    Popularity: 0.37911300000000003
    Budget: 0
    Revenue: 0
    Title: My Little Pony: Equestria Girls - Rainbow Rocks
    Popularity: 0.360228
    Budget: 0
    Revenue: 0
    Title: Reclaim
    Popularity: 0.35239299999999996
    Budget: 0
    Revenue: 0
    Title: Starry Eyes
    Popularity: 0.5395979999999989
    Budget: 0
    Revenue: 0
    Title: Debug
    Popularity: 0.324403
    Budget: 0
    Revenue: 0
    Title: Cooties
    Popularity: 0.689942
    Budget: 0
    Revenue: 0
    Title: Viking: The Berserkers
    Popularity: 0.512023
    Budget: 0
    Revenue: 0
    Title: The Dark Horse
    Popularity: 0.302498
    Budget: 0
    Revenue: 0
    Title: Don't Blink
    Popularity: 0.29562
    Budget: 0
    Revenue: 0
    Title: Horsehead
    Popularity: 0.292107
    Budget: 0
    Revenue: 0
    Title: The One I Love
    Popularity: 0.289951
    Budget: 0
    Revenue: 0
    Title: Blood Punch
    Popularity: 0.288035
    Budget: 0
    Revenue: 0
    Title: Dinosaur Island
    Popularity: 0.279115
    Budget: 0
    Revenue: 0
    Title: Zapped
    Popularity: 0.272995
    Budget: 0
    Revenue: 0
    Title: Expelled
    Popularity: 0.26927399999999996
    Budget: 0
    Revenue: 0
    Title: Savaged
    Popularity: 0.261284
    Budget: 0
    Revenue: 0
    Title: Scooby-Doo! WrestleMania Mystery
    Popularity: 0.256655
    Budget: 0
    Revenue: 0
    Title: Houdini
    Popularity: 0.342044
    Budget: 0
    Revenue: 0
    Title: Life Partners
    Popularity: 0.23157800000000003
    Budget: 0
    Revenue: 8265
    Title: Mockingbird
    Popularity: 0.227613
    Budget: 0
    Revenue: 0
    Title: The Well
    Popularity: 0.43327299999999996
    Budget: 0
    Revenue: 0
    Title: Almost Home
    Popularity: 0.219862
    Budget: 0
    Revenue: 0
    Title: My Man is a Loser
    Popularity: 0.212083
    Budget: 0
    Revenue: 0
    Title: Deep in the Darkness
    Popularity: 0.171104
    Budget: 0
    Revenue: 0
    Title: The Frame
    Popularity: 0.203043
    Budget: 0
    Revenue: 0
    Title: The Falling
    Popularity: 0.201445
    Budget: 0
    Revenue: 0
    Title: Creep
    Popularity: 0.19733599999999998
    Budget: 0
    Revenue: 0
    Title: Queen and Country
    Popularity: 0.18013900000000002
    Budget: 0
    Revenue: 0
    Title: Lilting
    Popularity: 0.177674
    Budget: 0
    Revenue: 0
    Title: 9 Kisses
    Popularity: 0.17561500000000002
    Budget: 0
    Revenue: 0
    Title: Ironclad 2: Battle for Blood
    Popularity: 0.169396
    Budget: 0
    Revenue: 0
    Title: Saint Laurent
    Popularity: 0.288731
    Budget: 0
    Revenue: 0
    Title: WolfCop
    Popularity: 0.16367400000000001
    Budget: 0
    Revenue: 0
    Title: Cat Run 2
    Popularity: 0.23546799999999998
    Budget: 0
    Revenue: 0
    Title: Take Care
    Popularity: 0.158245
    Budget: 0
    Revenue: 0
    Title: Sharktopus vs Pteracuda
    Popularity: 0.151929
    Budget: 0
    Revenue: 0
    Title: Ascension
    Popularity: 0.028695
    Budget: 0
    Revenue: 0
    Title: Whitey: United States of America v. James J. Bulger
    Popularity: 0.140245
    Budget: 0
    Revenue: 0
    Title: Two Men in Town
    Popularity: 0.26608699999999996
    Budget: 0
    Revenue: 0
    Title: Elephant Song
    Popularity: 0.140935
    Budget: 0
    Revenue: 0
    Title: We'll Never Have Paris
    Popularity: 0.12468499999999999
    Budget: 0
    Revenue: 0
    Title: Killer Legends
    Popularity: 0.113265
    Budget: 0
    Revenue: 0
    Title: The Mummy Resurrected
    Popularity: 0.109904
    Budget: 0
    Revenue: 0
    Title: Gunday
    Popularity: 0.20035999999999998
    Budget: 0
    Revenue: 0
    Title: The Perfect Wave
    Popularity: 0.097665
    Budget: 0
    Revenue: 0
    Title: The Houses October Built
    Popularity: 0.09563300000000001
    Budget: 0
    Revenue: 0
    Title: Road
    Popularity: 0.095131
    Budget: 0
    Revenue: 0
    Title: No No: A Dockumentary
    Popularity: 0.093062
    Budget: 0
    Revenue: 0
    Title: Bill Burr: I'm Sorry You Feel That Way
    Popularity: 0.083258
    Budget: 0
    Revenue: 0
    Title: Night Will Fall
    Popularity: 0.045555
    Budget: 0
    Revenue: 0
    Title: Breakup Buddies
    Popularity: 0.078644
    Budget: 0
    Revenue: 0
    Title: Merchants of Doubt
    Popularity: 0.075351
    Budget: 0
    Revenue: 192400
    Title: Mardaani
    Popularity: 0.015668
    Budget: 0
    Revenue: 0
    Title: Showrunners: The Art of Running a TV Show
    Popularity: 0.064238
    Budget: 0
    Revenue: 0
    Title: Heaven Adores You
    Popularity: 0.185882
    Budget: 0
    Revenue: 0
    Title: All This Mayhem
    Popularity: 0.048493
    Budget: 0
    Revenue: 0
    Title: To Be Takei
    Popularity: 0.190655
    Budget: 0
    Revenue: 0
    Title: Tim Maia
    Popularity: 0.036904
    Budget: 0
    Revenue: 0
    Title: Ballet 422
    Popularity: 0.023903
    Budget: 0
    Revenue: 0
    Title: The Dead Lands
    Popularity: 0.020923
    Budget: 0
    Revenue: 5240
    Title: Kill Dil
    Popularity: 0.044654
    Budget: 0
    Revenue: 0
    Title: Rich Hill
    Popularity: 0.023872
    Budget: 0
    Revenue: 0
    Title: The Serpent's Egg
    Popularity: 0.062898
    Budget: 0
    Revenue: 0
    Title: Day of the Animals
    Popularity: 0.046957
    Budget: 0
    Revenue: 0
    Title: Tanner Hall
    Popularity: 0.378554
    Budget: 0
    Revenue: 0
    Title: Der Knochenmann
    Popularity: 0.369406
    Budget: 0
    Revenue: 0
    Title: The Private Lives of Pippa Lee
    Popularity: 0.336426
    Budget: 0
    Revenue: 0
    Title: Nine Miles Down
    Popularity: 0.332142
    Budget: 0
    Revenue: 0
    Title: The House of the Devil
    Popularity: 0.31344
    Budget: 0
    Revenue: 0
    Title: Prayers for Bobby
    Popularity: 0.302095
    Budget: 0
    Revenue: 0
    Title: Serious Moonlight
    Popularity: 0.279941
    Budget: 0
    Revenue: 0
    Title: Summer's Blood
    Popularity: 0.266625
    Budget: 0
    Revenue: 0
    Title: Leningrad
    Popularity: 0.258982
    Budget: 0
    Revenue: 0
    Title: Under the Sea 3D
    Popularity: 0.251166
    Budget: 0
    Revenue: 0
    Title: Taking Woodstock
    Popularity: 0.23504499999999998
    Budget: 0
    Revenue: 0
    Title: Notorious
    Popularity: 0.232346
    Budget: 0
    Revenue: 43051547
    Title: Perrierâ€™s Bounty
    Popularity: 0.20979
    Budget: 0
    Revenue: 0
    Title: Not Forgotten
    Popularity: 0.206657
    Budget: 0
    Revenue: 0
    Title: The September Issue
    Popularity: 0.195364
    Budget: 0
    Revenue: 0
    Title: Mega Shark vs Giant Octopus
    Popularity: 0.187796
    Budget: 0
    Revenue: 0
    Title: Command Performance
    Popularity: 0.168985
    Budget: 0
    Revenue: 0
    Title: Infestation
    Popularity: 0.15559
    Budget: 0
    Revenue: 0
    Title: Coco
    Popularity: 0.141098
    Budget: 0
    Revenue: 0
    Title: Le Coach
    Popularity: 0.057316
    Budget: 0
    Revenue: 0
    Title: The Messengers 2: The Scarecrow
    Popularity: 0.123044
    Budget: 0
    Revenue: 0
    Title: The Marc Pease Experience
    Popularity: 0.246935
    Budget: 0
    Revenue: 0
    Title: Cairo Time
    Popularity: 0.107537
    Budget: 0
    Revenue: 0
    Title: Life
    Popularity: 0.10222300000000001
    Budget: 0
    Revenue: 0
    Title: Loose Change 9/11: An American Coup
    Popularity: 0.148198
    Budget: 0
    Revenue: 0
    Title: Art & Copy
    Popularity: 0.096111
    Budget: 0
    Revenue: 0
    Title: 35 Rhums
    Popularity: 0.0718299999999999
    Budget: 0
    Revenue: 0
    Title: La Guerre des Miss
    Popularity: 0.058977
    Budget: 0
    Revenue: 0
    Title: The Winning Season
    Popularity: 0.047028
    Budget: 0
    Revenue: 0
    Title: Logorama
    Popularity: 0.135759
    Budget: 0
    Revenue: 0
    Title: Un'estate ai Caraibi
    Popularity: 0.015926
    Budget: 0
    Revenue: 0
    Title: Map of the Sounds of Tokyo
    Popularity: 0.01217
    Budget: 0
    Revenue: 0
    Title: Nude Nuns With Big Guns
    Popularity: 0.62808
    Budget: 0
    Revenue: 0
    Title: Frozen
    Popularity: 0.538392
    Budget: 0
    Revenue: 3065860
    Title: Dog Pound
    Popularity: 0.47811800000000004
    Budget: 0
    Revenue: 430041
    Title: Titanic II
    Popularity: 0.407787
    Budget: 0
    Revenue: 0
    Title: And Soon the Darkness
    Popularity: 0.385303
    Budget: 0
    Revenue: 0
    Title: Inception: The Cobol Job
    Popularity: 0.34123000000000003
    Budget: 0
    Revenue: 0
    Title: En ganske snill mann
    Popularity: 0.319013
    Budget: 0
    Revenue: 0
    Title: Lying to Be Perfect
    Popularity: 0.27826799999999996
    Budget: 0
    Revenue: 0
    Title: Restrepo
    Popularity: 0.187905
    Budget: 0
    Revenue: 1422910
    Title: Space Chimps 2: Zartog Strikes Back
    Popularity: 0.2448
    Budget: 0
    Revenue: 0
    Title: Exorcismus
    Popularity: 0.22912399999999997
    Budget: 0
    Revenue: 0
    Title: Winnebago Man
    Popularity: 0.227258
    Budget: 0
    Revenue: 178174
    Title: Life Cycles
    Popularity: 0.222293
    Budget: 0
    Revenue: 0
    Title: Submarino
    Popularity: 0.20159100000000002
    Budget: 0
    Revenue: 0
    Title: Repeaters
    Popularity: 0.20523000000000002
    Budget: 0
    Revenue: 0
    Title: Territories
    Popularity: 0.195641
    Budget: 0
    Revenue: 0
    Title: The Trip
    Popularity: 0.182077
    Budget: 0
    Revenue: 951179
    Title: Peep World
    Popularity: 0.174224
    Budget: 0
    Revenue: 10967
    Title: Barbie in A Mermaid Tale
    Popularity: 0.170408
    Budget: 0
    Revenue: 0
    Title: Astral City: A Spiritual Journey
    Popularity: 0.160701
    Budget: 0
    Revenue: 0
    Title: Twelve
    Popularity: 0.12869
    Budget: 0
    Revenue: 0
    Title: Chain Letter
    Popularity: 0.150336
    Budget: 0
    Revenue: 0
    Title: Triple Dog
    Popularity: 0.141985
    Budget: 0
    Revenue: 0
    Title: Toast
    Popularity: 0.132502
    Budget: 0
    Revenue: 0
    Title: A Little Help
    Popularity: 0.067885
    Budget: 0
    Revenue: 0
    Title: Gasland
    Popularity: 0.087585
    Budget: 0
    Revenue: 0
    Title: 600 kilos d'or pur
    Popularity: 0.081724
    Budget: 0
    Revenue: 0
    Title: BearCity
    Popularity: 0.068941
    Budget: 0
    Revenue: 5980
    Title: FRED: The Movie
    Popularity: 0.064038
    Budget: 0
    Revenue: 0
    Title: Never Sleep Again: The Elm Street Legacy
    Popularity: 0.048672
    Budget: 0
    Revenue: 0
    Title: Boy
    Popularity: 0.028456
    Budget: 3
    Revenue: 43
    Title: I'm Here
    Popularity: 0.019247999999999998
    Budget: 0
    Revenue: 0
    Title: Rogue Trader
    Popularity: 0.301697
    Budget: 0
    Revenue: 0
    Title: Superstar
    Popularity: 0.296655
    Budget: 0
    Revenue: 0
    Title: Batman Beyond: The Movie
    Popularity: 0.096582
    Budget: 0
    Revenue: 0
    Title: Guest House Paradiso
    Popularity: 0.077584
    Budget: 0
    Revenue: 0
    Title: æˆé¾çš„ç‰¹æŠ€
    Popularity: 0.044502
    Budget: 0
    Revenue: 0
    Title: Sarfarosh
    Popularity: 0.015074
    Budget: 0
    Revenue: 0
    Title: Beethoven's 4th
    Popularity: 0.457617
    Budget: 0
    Revenue: 0
    Title: The Fourth Angel
    Popularity: 0.20342000000000002
    Budget: 0
    Revenue: 0
    Title: Uprising
    Popularity: 0.22135500000000002
    Budget: 0
    Revenue: 0
    Title: Scooby-Doo and the Cyber Chase
    Popularity: 0.210756
    Budget: 0
    Revenue: 0
    Title: James Dean
    Popularity: 0.151506
    Budget: 0
    Revenue: 0
    Title: Zenon: The Zequel
    Popularity: 0.017536000000000003
    Budget: 0
    Revenue: 0
    Title: Vizontele
    Popularity: 0.130018
    Budget: 0
    Revenue: 0
    Title: Holiday in the Sun
    Popularity: 0.200262
    Budget: 0
    Revenue: 0
    Title: The Luck of the Irish
    Popularity: 0.0619169999999999
    Budget: 0
    Revenue: 0
    Title: Fifty Dead Men Walking
    Popularity: 0.541117
    Budget: 0
    Revenue: 0
    Title: The Escapist
    Popularity: 0.47135600000000005
    Budget: 0
    Revenue: 0
    Title: Open Season 2
    Popularity: 0.45988500000000004
    Budget: 0
    Revenue: 0
    Title: The Echo
    Popularity: 0.407009
    Budget: 0
    Revenue: 0
    Title: Lost Boys: The Tribe
    Popularity: 0.399327
    Budget: 0
    Revenue: 0
    Title: Ben 10: Race Against Time
    Popularity: 0.390228
    Budget: 0
    Revenue: 0
    Title: Generation Kill
    Popularity: 0.336308
    Budget: 0
    Revenue: 0
    Title: Anaconda 3: Offspring
    Popularity: 0.316727
    Budget: 0
    Revenue: 0
    Title: The Lucky Ones
    Popularity: 0.287248
    Budget: 0
    Revenue: 0
    Title: Henry Poole Is Here
    Popularity: 0.283736
    Budget: 0
    Revenue: 1829917
    Title: Another Gay Sequel: Gays Gone Wild!
    Popularity: 0.264137
    Budget: 0
    Revenue: 0
    Title: The Haunting of Molly Hartley
    Popularity: 0.2552
    Budget: 0
    Revenue: 0
    Title: Blackout
    Popularity: 0.19023800000000002
    Budget: 0
    Revenue: 0
    Title: La Fille de Monaco
    Popularity: 0.22710999999999998
    Budget: 0
    Revenue: 0
    Title: Kit Kittredge: An American Girl
    Popularity: 0.219277
    Budget: 0
    Revenue: 0
    Title: Jerusalema
    Popularity: 0.178752
    Budget: 0
    Revenue: 0
    Title: Seventh Moon
    Popularity: 0.16095
    Budget: 0
    Revenue: 0
    Title: The Black Balloon
    Popularity: 0.14485399999999898
    Budget: 0
    Revenue: 0
    Title: Visioneers
    Popularity: 0.137976
    Budget: 0
    Revenue: 0
    Title: Shine a Light
    Popularity: 0.134056999999999
    Budget: 0
    Revenue: 0
    Title: Le Silence de Lorna
    Popularity: 0.117631
    Budget: 0
    Revenue: 0
    Title: Bigger Stronger Faster*
    Popularity: 0.111351
    Budget: 0
    Revenue: 307811
    Title: Not Quite Hollywood
    Popularity: 0.329196
    Budget: 0
    Revenue: 0
    Title: Princess
    Popularity: 0.076837
    Budget: 0
    Revenue: 0
    Title: Strictly Sexual
    Popularity: 0.068383
    Budget: 0
    Revenue: 0
    Title: Maradona by Kusturica
    Popularity: 0.043578
    Budget: 0
    Revenue: 0
    Title: Meu Nome NÃ£o Ã‰ Johnny
    Popularity: 0.033615
    Budget: 0
    Revenue: 0
    Title: John Adams
    Popularity: 0.13654000000000002
    Budget: 0
    Revenue: 0
    Title: Disgrace
    Popularity: 0.0175199999999999
    Budget: 0
    Revenue: 0
    Title: Geek Charming
    Popularity: 0.607142
    Budget: 0
    Revenue: 0
    Title: Batman: Year One
    Popularity: 0.559451
    Budget: 0
    Revenue: 0
    Title: Megamind: The Button Of Doom
    Popularity: 0.49264600000000003
    Budget: 0
    Revenue: 0
    Title: Urbanized
    Popularity: 0.4483
    Budget: 0
    Revenue: 0
    Title: Barbie: Princess Charm School
    Popularity: 0.385492
    Budget: 0
    Revenue: 0
    Title: The Art of Flight
    Popularity: 0.321341
    Budget: 0
    Revenue: 0
    Title: Red Dog
    Popularity: 0.30289
    Budget: 0
    Revenue: 0
    Title: There Be Dragons
    Popularity: 0.293453
    Budget: 0
    Revenue: 0
    Title: Wild Bill
    Popularity: 0.279592
    Budget: 0
    Revenue: 0
    Title: The River Murders
    Popularity: 0.24997800000000003
    Budget: 0
    Revenue: 0
    Title: The Suite Life Movie
    Popularity: 0.22973400000000002
    Budget: 0
    Revenue: 0
    Title: Woody Allen: A Documentary
    Popularity: 0.271394
    Budget: 0
    Revenue: 0
    Title: Panic Button
    Popularity: 0.246038
    Budget: 0
    Revenue: 0
    Title: La Nouvelle Guerre des boutons
    Popularity: 0.184658
    Budget: 0
    Revenue: 0
    Title: Project Nim
    Popularity: 0.181614
    Budget: 0
    Revenue: 0
    Title: Burning Man
    Popularity: 0.172285
    Budget: 0
    Revenue: 0
    Title: Sand Sharks
    Popularity: 0.159707
    Budget: 0
    Revenue: 0
    Title: A Haunting in Salem
    Popularity: 0.133719
    Budget: 0
    Revenue: 0
    Title: Conan O'Brien Can't Stop
    Popularity: 0.129723
    Budget: 0
    Revenue: 223959
    Title: Thor - Tales of Asgard
    Popularity: 0.122656
    Budget: 0
    Revenue: 3100000
    Title: Lucky
    Popularity: 0.104959
    Budget: 0
    Revenue: 0
    Title: La Guerre Des Boutons
    Popularity: 0.09734
    Budget: 0
    Revenue: 0
    Title: Being Elmo: A Puppeteer's Journey
    Popularity: 0.08326900000000001
    Budget: 0
    Revenue: 286201
    Title: Steve Jobs: Billion Dollar Hippy
    Popularity: 0.076679
    Budget: 0
    Revenue: 0
    Title: The Amityville Haunting
    Popularity: 0.063811
    Budget: 0
    Revenue: 0
    Title: Hollow
    Popularity: 0.08405800000000001
    Budget: 0
    Revenue: 0
    Title: Dear Santa
    Popularity: 0.018633
    Budget: 0
    Revenue: 0
    Title: Une bouteille Ã  la mer
    Popularity: 0.060639
    Budget: 0
    Revenue: 0
    Title: Cadet Kelly
    Popularity: 0.359055
    Budget: 0
    Revenue: 0
    Title: Deathwatch
    Popularity: 0.303609
    Budget: 0
    Revenue: 0
    Title: Carrie
    Popularity: 0.257263
    Budget: 0
    Revenue: 0
    Title: Get a Clue
    Popularity: 0.244263
    Budget: 0
    Revenue: 0
    Title: Better Luck Tomorrow
    Popularity: 0.147215
    Budget: 0
    Revenue: 0
    Title: Tuck Everlasting
    Popularity: 0.128012
    Budget: 0
    Revenue: 0
    Title: Stealing Harvard
    Popularity: 0.104804
    Budget: 0
    Revenue: 0
    Title: The Master of Disguise
    Popularity: 0.02912
    Budget: 0
    Revenue: 0
    Title: Ping Pong
    Popularity: 0.0769
    Budget: 0
    Revenue: 0
    Title: An Evening with Kevin Smith
    Popularity: 0.041099000000000004
    Budget: 0
    Revenue: 0
    Title: Quiz Show
    Popularity: 0.637496
    Budget: 0
    Revenue: 0
    Title: Wolf
    Popularity: 0.43758100000000005
    Budget: 0
    Revenue: 0
    Title: The Cowboy Way
    Popularity: 0.363695
    Budget: 0
    Revenue: 0
    Title: Trapped in Paradise
    Popularity: 0.317848
    Budget: 0
    Revenue: 5777916
    Title: Immortal Beloved
    Popularity: 0.40429499999999996
    Budget: 0
    Revenue: 0
    Title: A Simple Twist of Fate
    Popularity: 0.16978800000000002
    Budget: 0
    Revenue: 0
    Title: The Scout
    Popularity: 0.148301
    Budget: 0
    Revenue: 0
    Title: Crumb
    Popularity: 0.135668
    Budget: 0
    Revenue: 3174695
    Title: Pumpkinhead II: Blood Wings
    Popularity: 0.061916
    Budget: 0
    Revenue: 0
    Title: From Beijing with Love
    Popularity: 0.099562
    Budget: 0
    Revenue: 0
    Title: Hercules and the Lost Kingdom
    Popularity: 0.073496
    Budget: 0
    Revenue: 0
    Title: Hercules in the Maze of the Minotaur
    Popularity: 0.204483
    Budget: 0
    Revenue: 0
    Title: So Undercover
    Popularity: 0.524246
    Budget: 0
    Revenue: 0
    Title: Io e te
    Popularity: 0.518686
    Budget: 0
    Revenue: 0
    Title: Emperor
    Popularity: 0.474818
    Budget: 0
    Revenue: 3346265
    Title: The Brass Teapot
    Popularity: 0.460239
    Budget: 0
    Revenue: 0
    Title: Cirque du Soleil: Worlds Away
    Popularity: 0.448325
    Budget: 0
    Revenue: 34153101
    Title: Tong que tai
    Popularity: 0.43873
    Budget: 0
    Revenue: 0
    Title: I Am Bruce Lee
    Popularity: 0.403624
    Budget: 0
    Revenue: 0
    Title: 3, 2, 1... Frankie Go Boom
    Popularity: 0.31262399999999996
    Budget: 0
    Revenue: 0
    Title: Loosies
    Popularity: 0.34655199999999997
    Budget: 0
    Revenue: 0
    Title: Cesare deve morire
    Popularity: 0.32297800000000004
    Budget: 0
    Revenue: 0
    Title: Big Time Movie
    Popularity: 0.25737
    Budget: 0
    Revenue: 0
    Title: The Magic of Belle Isle
    Popularity: 0.315868
    Budget: 0
    Revenue: 102388
    Title: Le Guetteur
    Popularity: 0.292387
    Budget: 0
    Revenue: 0
    Title: Storage 24
    Popularity: 0.287294
    Budget: 0
    Revenue: 0
    Title: Une vie meilleure
    Popularity: 0.281092
    Budget: 0
    Revenue: 0
    Title: More Than Honey
    Popularity: 0.222923
    Budget: 0
    Revenue: 0
    Title: Love, Marilyn
    Popularity: 0.474678
    Budget: 0
    Revenue: 0
    Title: Devil Seed
    Popularity: 0.253871
    Budget: 0
    Revenue: 0
    Title: Something from Nothing: The Art of Rap
    Popularity: 0.235271
    Budget: 0
    Revenue: 288312
    Title: Jesus Henry Christ
    Popularity: 0.22647399999999998
    Budget: 0
    Revenue: 0
    Title: A Fantastic Fear of Everything
    Popularity: 0.21860500000000002
    Budget: 0
    Revenue: 0
    Title: Jayne Mansfield's Car
    Popularity: 0.180989
    Budget: 0
    Revenue: 0
    Title: Beverly Hills Chihuahua 3 - Viva La Fiesta!
    Popularity: 0.207878
    Budget: 0
    Revenue: 0
    Title: The Pervert's Guide to Ideology
    Popularity: 0.200707
    Budget: 0
    Revenue: 0
    Title: World Without End
    Popularity: 0.17924
    Budget: 0
    Revenue: 0
    Title: Kauwboy
    Popularity: 0.171625
    Budget: 0
    Revenue: 0
    Title: Il Ã©tait une fois, une fois
    Popularity: 0.14562
    Budget: 0
    Revenue: 0
    Title: Any Day Now
    Popularity: 0.154043
    Budget: 0
    Revenue: 0
    Title: Maggie Simpson in The Longest Daycare
    Popularity: 0.150035
    Budget: 0
    Revenue: 0
    Title: Mansome
    Popularity: 0.14271
    Budget: 0
    Revenue: 0
    Title: Rags
    Popularity: 0.140016
    Budget: 0
    Revenue: 0
    Title: The Barrens
    Popularity: 0.13479000000000002
    Budget: 0
    Revenue: 0
    Title: Marina AbramoviÄ‡: The Artist Is Present
    Popularity: 0.201188
    Budget: 0
    Revenue: 0
    Title: Dead Before Dawn 3D
    Popularity: 0.126328
    Budget: 0
    Revenue: 0
    Title: Spike Island
    Popularity: 0.11380799999999999
    Budget: 0
    Revenue: 0
    Title: PokÅ‚osie
    Popularity: 0.10015700000000001
    Budget: 0
    Revenue: 0
    Title: Bad Kids Go to Hell
    Popularity: 0.09156399999999999
    Budget: 0
    Revenue: 0
    Title: Amy Schumer: Mostly Sex Stuff
    Popularity: 0.0898409999999999
    Budget: 0
    Revenue: 0
    Title: It's a SpongeBob Christmas!
    Popularity: 0.0851789999999999
    Budget: 0
    Revenue: 0
    Title: Girls Against Boys
    Popularity: 0.077988
    Budget: 0
    Revenue: 0
    Title: The Queen of Versailles
    Popularity: 0.066122
    Budget: 0
    Revenue: 714544
    Title: Minecraft: The Story of Mojang
    Popularity: 0.055791999999999994
    Budget: 0
    Revenue: 0
    Title: Fresh Meat
    Popularity: 0.043949
    Budget: 0
    Revenue: 0
    Title: Sassy Pants
    Popularity: 0.034628
    Budget: 0
    Revenue: 0
    Title: Adam and Dog
    Popularity: 0.081053
    Budget: 0
    Revenue: 0
    Title: Hold Your Breath
    Popularity: 0.023223
    Budget: 0
    Revenue: 0
    Title: KumarÃ©
    Popularity: 0.019797
    Budget: 0
    Revenue: 0
    Title: Liz & Dick
    Popularity: 0.0153509999999999
    Budget: 0
    Revenue: 0
    Title: What a Girl Wants
    Popularity: 0.699833
    Budget: 0
    Revenue: 0
    Title: Scorched
    Popularity: 0.454926
    Budget: 0
    Revenue: 0
    Title: The In-Laws
    Popularity: 0.331948
    Budget: 0
    Revenue: 20440627
    Title: Scooby-Doo! and the Monster of Mexico
    Popularity: 0.326083
    Budget: 0
    Revenue: 0
    Title: Le temps du loup
    Popularity: 0.240657
    Budget: 0
    Revenue: 0
    Title: Tiptoes
    Popularity: 0.220344
    Budget: 0
    Revenue: 0
    Title: All the Real Girls
    Popularity: 0.21879899999999997
    Budget: 0
    Revenue: 0
    Title: Helen of Troy
    Popularity: 0.154678
    Budget: 0
    Revenue: 0
    Title: The Shape of Things
    Popularity: 0.14657
    Budget: 0
    Revenue: 0
    Title: The Diary of Ellen Rimbauer
    Popularity: 0.175648
    Budget: 0
    Revenue: 0
    Title: Chalte Chalte
    Popularity: 0.085589
    Budget: 0
    Revenue: 0
    Title: Madea's Class Reunion
    Popularity: 0.073665
    Budget: 0
    Revenue: 0
    Title: A Detective Story
    Popularity: 0.168156
    Budget: 0
    Revenue: 0
    Title: The Room
    Popularity: 0.038307
    Budget: 0
    Revenue: 0
    Title: The Second Renaissance Part II
    Popularity: 0.013546
    Budget: 0
    Revenue: 0
    Title: Fierce Creatures
    Popularity: 0.340289
    Budget: 0
    Revenue: 9381260
    Title: Gang Related
    Popularity: 0.179786
    Budget: 0
    Revenue: 5790448
    Title: Trekkies
    Popularity: 0.14890499999999898
    Budget: 0
    Revenue: 0
    Title: Leave it to Beaver
    Popularity: 0.143585
    Budget: 0
    Revenue: 0
    Title: Soul Food
    Popularity: 0.076214
    Budget: 0
    Revenue: 0
    Title: Le Pari
    Popularity: 0.139139
    Budget: 0
    Revenue: 0
    Title: Love Punch
    Popularity: 0.67143
    Budget: 0
    Revenue: 0
    Title: Doctor Who: The Day of the Doctor
    Popularity: 0.661187
    Budget: 0
    Revenue: 0
    Title: A Common Man
    Popularity: 0.607881
    Budget: 0
    Revenue: 0
    Title: The Pirate Bay: Away From Keyboard
    Popularity: 0.572994
    Budget: 0
    Revenue: 34664
    Title: Very Good Girls
    Popularity: 0.481309
    Budget: 0
    Revenue: 0
    Title: Trust Me
    Popularity: 0.470645
    Budget: 0
    Revenue: 0
    Title: Hammer of the Gods
    Popularity: 0.466871
    Budget: 0
    Revenue: 641
    Title: The Last of Robin Hood
    Popularity: 0.43174700000000005
    Budget: 0
    Revenue: 0
    Title: The Invisible Woman
    Popularity: 0.42018500000000003
    Budget: 0
    Revenue: 1234254
    Title: As I Lay Dying
    Popularity: 0.384925
    Budget: 0
    Revenue: 0
    Title: Hateship Loveship
    Popularity: 0.376959
    Budget: 0
    Revenue: 0
    Title: Child of God
    Popularity: 0.36947800000000003
    Budget: 0
    Revenue: 0
    Title: A Madea Christmas
    Popularity: 0.349655
    Budget: 0
    Revenue: 0
    Title: Eastern Boys
    Popularity: 0.10543399999999999
    Budget: 0
    Revenue: 0
    Title: A Birder's Guide to Everything
    Popularity: 0.321236
    Budget: 0
    Revenue: 0
    Title: Suddenly
    Popularity: 0.315607
    Budget: 0
    Revenue: 0
    Title: Robosapien: Rebooted
    Popularity: 0.313089
    Budget: 0
    Revenue: 0
    Title: The Truth About Emanuel
    Popularity: 0.30409899999999895
    Budget: 0
    Revenue: 0
    Title: One Small Hitch
    Popularity: 0.283595
    Budget: 0
    Revenue: 7965
    Title: Kill for Me
    Popularity: 0.210216
    Budget: 0
    Revenue: 0
    Title: Blackfish
    Popularity: 0.278117
    Budget: 0
    Revenue: 0
    Title: I Declare War
    Popularity: 0.26826300000000003
    Budget: 0
    Revenue: 0
    Title: Antisocial
    Popularity: 0.258887
    Budget: 0
    Revenue: 0
    Title: The Inevitable Defeat of Mister & Pete
    Popularity: 0.249284
    Budget: 0
    Revenue: 0
    Title: Return to Nim's Island
    Popularity: 0.22484200000000001
    Budget: 0
    Revenue: 0
    Title: Magic Magic
    Popularity: 0.22088200000000002
    Budget: 0
    Revenue: 0
    Title: The Unknown Known
    Popularity: 0.21735300000000002
    Budget: 0
    Revenue: 0
    Title: Forbidden Ground
    Popularity: 0.213141
    Budget: 0
    Revenue: 0
    Title: Tesis sobre un homicidio
    Popularity: 0.206724
    Budget: 0
    Revenue: 0
    Title: The Blue Umbrella
    Popularity: 0.197857
    Budget: 0
    Revenue: 0
    Title: Phil Spector
    Popularity: 0.168935
    Budget: 0
    Revenue: 0
    Title: ëª½íƒ€ì£¼
    Popularity: 0.18767
    Budget: 0
    Revenue: 0
    Title: Non-Stop
    Popularity: 0.051172
    Budget: 0
    Revenue: 0
    Title: Three Night Stand
    Popularity: 0.131381
    Budget: 0
    Revenue: 0
    Title: Wrong Cops
    Popularity: 0.168658
    Budget: 0
    Revenue: 0
    Title: Gerontophilia
    Popularity: 0.16608599999999898
    Budget: 0
    Revenue: 4793
    Title: Tropico
    Popularity: 0.107333
    Budget: 0
    Revenue: 0
    Title: Crystal Fairy & the Magical Cactus
    Popularity: 0.35145
    Budget: 0
    Revenue: 0
    Title: Swindle
    Popularity: 0.147641
    Budget: 0
    Revenue: 0
    Title: Prisoners of the Sun
    Popularity: 0.139629
    Budget: 18
    Revenue: 0
    Title: Chariot
    Popularity: 0.13836500000000002
    Budget: 0
    Revenue: 0
    Title: We Steal Secrets: The Story of WikiLeaks
    Popularity: 0.407065
    Budget: 0
    Revenue: 602042
    Title: The Frankenstein Theory
    Popularity: 0.134168
    Budget: 0
    Revenue: 0
    Title: Lucky Them
    Popularity: 0.131561999999999
    Budget: 0
    Revenue: 0
    Title: Top Gear: The Perfect Road Trip
    Popularity: 0.165605
    Budget: 0
    Revenue: 0
    Title: C.O.G.
    Popularity: 0.10648900000000001
    Budget: 0
    Revenue: 0
    Title: Girl Rising
    Popularity: 0.213552
    Budget: 0
    Revenue: 0
    Title: Gori Tere Pyaar Mein
    Popularity: 0.09045800000000001
    Budget: 0
    Revenue: 342000
    Title: Les grandes ondes (Ã  l'ouest)
    Popularity: 0.060425
    Budget: 0
    Revenue: 0
    Title: La gran familia espaÃ±ola
    Popularity: 0.070124
    Budget: 0
    Revenue: 0
    Title: R'ha
    Popularity: 0.096356
    Budget: 0
    Revenue: 0
    Title: Narco Cultura
    Popularity: 0.080336
    Budget: 0
    Revenue: 0
    Title: Paradise
    Popularity: 0.050881
    Budget: 0
    Revenue: 0
    Title: Mr. Jones
    Popularity: 0.041543000000000004
    Budget: 0
    Revenue: 0
    Title: The Story of Luke
    Popularity: 0.036702
    Budget: 0
    Revenue: 0
    Title: Jimi Hendrix: Hear My Train A Comin'
    Popularity: 0.023757
    Budget: 0
    Revenue: 0
    Title: Sacro GRA
    Popularity: 0.01993
    Budget: 0
    Revenue: 0
    Title: Spies Like Us
    Popularity: 0.480534
    Budget: 0
    Revenue: 0
    Title: Ewoks: The Battle for Endor
    Popularity: 0.393399
    Budget: 0
    Revenue: 0
    Title: Kiss of the Spider Woman
    Popularity: 0.334805
    Budget: 0
    Revenue: 0
    Title: White Nights
    Popularity: 0.322151
    Budget: 0
    Revenue: 42160849
    Title: Vision Quest
    Popularity: 0.047123000000000005
    Budget: 0
    Revenue: 0
    Title: An American Haunting
    Popularity: 0.429125
    Budget: 0
    Revenue: 0
    Title: Beowulf & Grendel
    Popularity: 0.423386
    Budget: 0
    Revenue: 92076
    Title: Last Days
    Popularity: 0.335779
    Budget: 0
    Revenue: 1928985
    Title: Boo
    Popularity: 0.292346
    Budget: 0
    Revenue: 0
    Title: Underclassman
    Popularity: 0.28021
    Budget: 0
    Revenue: 0
    Title: Babam ve oÄŸlum
    Popularity: 0.26500799999999997
    Budget: 0
    Revenue: 0
    Title: The Triangle
    Popularity: 0.225647
    Budget: 0
    Revenue: 0
    Title: The Business
    Popularity: 0.217455
    Budget: 0
    Revenue: 0
    Title: The Notorious Bettie Page
    Popularity: 0.16350499999999898
    Budget: 0
    Revenue: 1410778
    Title: Reefer Madness: The Movie Musical
    Popularity: 0.130215
    Budget: 0
    Revenue: 0
    Title: Boudu
    Popularity: 0.09183999999999999
    Budget: 0
    Revenue: 0
    Title: The Poseidon Adventure
    Popularity: 0.145446
    Budget: 0
    Revenue: 0
    Title: La Moustache
    Popularity: 0.063725
    Budget: 0
    Revenue: 0
    Title: I'll Always Know What You Did Last Summer
    Popularity: 0.520258
    Budget: 0
    Revenue: 0
    Title: The Little Matchgirl
    Popularity: 0.371028
    Budget: 0
    Revenue: 0
    Title: Find Me Guilty
    Popularity: 0.35186999999999996
    Budget: 0
    Revenue: 0
    Title: Happily N'Ever After
    Popularity: 0.340571
    Budget: 0
    Revenue: 0
    Title: é»‘ç¤¾ä¼š2ï¼šä»¥å’Œä¸ºè´µ
    Popularity: 0.27504
    Budget: 0
    Revenue: 0
    Title: Poultrygeist: Night of the Chicken Dead
    Popularity: 0.15219100000000002
    Budget: 0
    Revenue: 0
    Title: Bernard and Doris
    Popularity: 0.267119
    Budget: 0
    Revenue: 0
    Title: Alien Autopsy
    Popularity: 0.245865
    Budget: 0
    Revenue: 0
    Title: Return to Halloweentown
    Popularity: 0.235116
    Budget: 0
    Revenue: 0
    Title: EnfermÃ©s dehors
    Popularity: 0.201755
    Budget: 0
    Revenue: 0
    Title: The Darwin Awards
    Popularity: 0.170775
    Budget: 0
    Revenue: 0
    Title: Right at Your Door
    Popularity: 0.1546
    Budget: 0
    Revenue: 2043704
    Title: The Tripper
    Popularity: 0.136505
    Budget: 0
    Revenue: 0
    Title: Mini's First Time
    Popularity: 0.113193
    Budget: 0
    Revenue: 0
    Title: This Film Is Not Yet Rated
    Popularity: 0.10827200000000001
    Budget: 0
    Revenue: 302179
    Title: The Cheetah Girls 2
    Popularity: 0.092151
    Budget: 0
    Revenue: 0
    Title: Kiwi!
    Popularity: 0.0760779999999999
    Budget: 0
    Revenue: 0
    Title: Doogal
    Popularity: 0.062503
    Budget: 0
    Revenue: 0
    Title: Jane Eyre
    Popularity: 0.065206
    Budget: 0
    Revenue: 0
    Title: Comme t'y es belle
    Popularity: 0.032666
    Budget: 0
    Revenue: 0
    Title: The Zodiac
    Popularity: 0.017169
    Budget: 0
    Revenue: 0
    Title: Highwaymen
    Popularity: 0.5046069999999989
    Budget: 0
    Revenue: 371396
    Title: In Good Company
    Popularity: 0.47558900000000004
    Budget: 0
    Revenue: 0
    Title: In My Father's Den
    Popularity: 0.354348
    Budget: 0
    Revenue: 0
    Title: Jack-Jack Attack
    Popularity: 0.329563
    Budget: 0
    Revenue: 0
    Title: Saving Face
    Popularity: 0.23647100000000001
    Budget: 0
    Revenue: 0
    Title: What the #$*! Do We (K)now!?
    Popularity: 0.203253
    Budget: 0
    Revenue: 10000000
    Title: Le Convoyeur
    Popularity: 0.183345
    Budget: 0
    Revenue: 0
    Title: The Toolbox Murders
    Popularity: 0.164872
    Budget: 0
    Revenue: 0
    Title: Creep
    Popularity: 0.126695
    Budget: 0
    Revenue: 0
    Title: Mensonges Et Trahisons Et Plus Si AffinitÃ©s...
    Popularity: 0.057343
    Budget: 0
    Revenue: 0
    Title: I Am David
    Popularity: 0.188156
    Budget: 0
    Revenue: 0
    Title: The Life and Times of Judge Roy Bean
    Popularity: 0.130781
    Budget: 0
    Revenue: 0
    Title: The Gods Must Be Crazy
    Popularity: 0.681446
    Budget: 0
    Revenue: 0
    Title: The Dogs of War
    Popularity: 0.359586
    Budget: 0
    Revenue: 0
    Title: The Big Red One
    Popularity: 0.28902
    Budget: 0
    Revenue: 7206220
    Title: Saturn 3
    Popularity: 0.323615
    Budget: 0
    Revenue: 0
    Title: Brubaker
    Popularity: 0.156245
    Budget: 0
    Revenue: 37121708
    Title: Where the Buffalo Roam
    Popularity: 0.097584
    Budget: 0
    Revenue: 6659377
    Title: Forbidden Zone
    Popularity: 0.086854
    Budget: 0
    Revenue: 0
    Title: Hopscotch
    Popularity: 0.042615
    Budget: 0
    Revenue: 0
    Title: Return to House on Haunted Hill
    Popularity: 0.464192
    Budget: 0
    Revenue: 0
    Title: Bratz
    Popularity: 0.395397
    Budget: 0
    Revenue: 0
    Title: Bury My Heart At Wounded Knee
    Popularity: 0.360061
    Budget: 0
    Revenue: 0
    Title: La HabitaciÃ³n de Fermat
    Popularity: 0.30690500000000004
    Budget: 0
    Revenue: 0
    Title: Gabriel
    Popularity: 0.273457
    Budget: 0
    Revenue: 0
    Title: Pigs
    Popularity: 0.258705
    Budget: 0
    Revenue: 0
    Title: Cougar Club
    Popularity: 0.23889699999999997
    Budget: 0
    Revenue: 0
    Title: Balls of Fury
    Popularity: 0.188155
    Budget: 0
    Revenue: 41098065
    Title: Hellphone
    Popularity: 0.167408
    Budget: 0
    Revenue: 0
    Title: Primeval
    Popularity: 0.314684
    Budget: 0
    Revenue: 10597734
    Title: End of the Line
    Popularity: 0.146603
    Budget: 0
    Revenue: 0
    Title: Hounddog
    Popularity: 0.132769
    Budget: 0
    Revenue: 0
    Title: Sublime
    Popularity: 0.326556
    Budget: 0
    Revenue: 0
    Title: Super High Me
    Popularity: 0.118177
    Budget: 0
    Revenue: 0
    Title: The Go-Getter
    Popularity: 0.109305
    Budget: 0
    Revenue: 0
    Title: Joy Division
    Popularity: 0.172227
    Budget: 0
    Revenue: 0
    Title: Heyy Babyy
    Popularity: 0.071965
    Budget: 0
    Revenue: 12000000
    Title: Magicians
    Popularity: 0.228927
    Budget: 0
    Revenue: 1752038
    Title: Bring It On: In It To Win It
    Popularity: 0.020513999999999998
    Budget: 0
    Revenue: 0
    Title: The Apple Dumpling Gang Rides Again
    Popularity: 0.141546
    Budget: 0
    Revenue: 0
    Title: The Wanderers
    Popularity: 0.110767
    Budget: 0
    Revenue: 0
    Title: Greystoke: The Legend of Tarzan, Lord of the Apes
    Popularity: 0.368967
    Budget: 0
    Revenue: 45858563
    Title: Cannonball Run II
    Popularity: 0.263945
    Budget: 0
    Revenue: 28078073
    Title: Tank
    Popularity: 0.222379
    Budget: 0
    Revenue: 14134877
    Title: Beat Street
    Popularity: 0.11825799999999999
    Budget: 0
    Revenue: 0
    Title: Screwballs
    Popularity: 0.363044
    Budget: 0
    Revenue: 0
    Title: Amityville 3-D
    Popularity: 0.336525
    Budget: 0
    Revenue: 6333135
    Title: Eddie Murphy: Delirious
    Popularity: 0.029945
    Budget: 0
    Revenue: 0
    Title: Copycat
    Popularity: 0.808542
    Budget: 0
    Revenue: 0
    Title: Bushwhacked
    Popularity: 0.469383
    Budget: 0
    Revenue: 0
    Title: The Englishman Who Went Up a Hill But Came Down a Mountain
    Popularity: 0.414233
    Budget: 0
    Revenue: 0
    Title: Richard III
    Popularity: 0.392875
    Budget: 0
    Revenue: 0
    Title: The Babysitter
    Popularity: 0.314238
    Budget: 0
    Revenue: 0
    Title: The Last Supper
    Popularity: 0.283428
    Budget: 0
    Revenue: 442965
    Title: Mr. Holland's Opus
    Popularity: 0.42167899999999997
    Budget: 0
    Revenue: 106269971
    Title: Haunted
    Popularity: 0.20571199999999998
    Budget: 0
    Revenue: 0
    Title: The Doom Generation
    Popularity: 0.052554
    Budget: 0
    Revenue: 0
    Title: The Muppet Christmas Carol
    Popularity: 0.6871970000000001
    Budget: 0
    Revenue: 27281507
    Title: Shining Through
    Popularity: 0.468679
    Budget: 0
    Revenue: 21621000
    Title: The Cutting Edge
    Popularity: 0.31095100000000003
    Budget: 0
    Revenue: 25105517
    Title: Critters 4
    Popularity: 0.26000300000000004
    Budget: 0
    Revenue: 0
    Title: Prelude to a Kiss
    Popularity: 0.23665999999999998
    Budget: 0
    Revenue: 22697691
    Title: Deep Cover
    Popularity: 0.134051
    Budget: 0
    Revenue: 0
    Title: Kuffs
    Popularity: 0.153994
    Budget: 0
    Revenue: 0
    Title: Un CÅ“ur en Hiver
    Popularity: 0.138521
    Budget: 0
    Revenue: 1666511
    Title: Blown Away
    Popularity: 0.028515
    Budget: 0
    Revenue: 0
    Title: Ragtime
    Popularity: 0.29427600000000004
    Budget: 0
    Revenue: 0
    Title: Looker
    Popularity: 0.156406
    Budget: 0
    Revenue: 0
    Title: Continental Divide
    Popularity: 0.062202
    Budget: 0
    Revenue: 15578237
    Title: 2 Days in the Valley
    Popularity: 0.694371
    Budget: 0
    Revenue: 0
    Title: Beautiful Girls
    Popularity: 0.38409699999999997
    Budget: 0
    Revenue: 0
    Title: Brassed Off
    Popularity: 0.17996199999999898
    Budget: 0
    Revenue: 0
    Title: Daai laap mat taam 008
    Popularity: 0.493379
    Budget: 0
    Revenue: 0
    Title: Ed
    Popularity: 0.141542
    Budget: 0
    Revenue: 0
    Title: Bernie
    Popularity: 0.028541000000000004
    Budget: 0
    Revenue: 0
    Title: Juste une question d'amour
    Popularity: 0.171378
    Budget: 0
    Revenue: 0
    Title: About Adam
    Popularity: 0.155496
    Budget: 0
    Revenue: 151559
    Title: Le goÃ»t des autres
    Popularity: 0.130962
    Budget: 0
    Revenue: 0
    Title: Leprechaun in the Hood
    Popularity: 0.402275
    Budget: 0
    Revenue: 0
    Title: Mission Kashmir
    Popularity: 0.0699029999999999
    Budget: 0
    Revenue: 0
    Title: Ali G, Aiii
    Popularity: 0.035184
    Budget: 0
    Revenue: 0
    Title: Tenebre
    Popularity: 0.492302
    Budget: 0
    Revenue: 0
    Title: Honkytonk Man
    Popularity: 0.360746
    Budget: 0
    Revenue: 0
    Title: Deathtrap
    Popularity: 0.24222
    Budget: 0
    Revenue: 0
    Title: Monty Python Live at the Hollywood Bowl
    Popularity: 0.176427
    Budget: 0
    Revenue: 0
    Title: Ren zhe wu di
    Popularity: 0.09902999999999999
    Budget: 0
    Revenue: 0
    Title: The Slumber Party Massacre
    Popularity: 0.058092
    Budget: 0
    Revenue: 0
    Title: Made in Britain
    Popularity: 0.104494
    Budget: 0
    Revenue: 0
    Title: BASEketball
    Popularity: 0.299293
    Budget: 0
    Revenue: 7027290
    Title: Another Day in Paradise
    Popularity: 0.33113000000000004
    Budget: 0
    Revenue: 0
    Title: Creature
    Popularity: 0.455013
    Budget: 0
    Revenue: 0
    Title: Scooby-Doo on Zombie Island
    Popularity: 0.29132199999999997
    Budget: 0
    Revenue: 0
    Title: Senseless
    Popularity: 0.276165
    Budget: 0
    Revenue: 13035599
    Title: Futuresport
    Popularity: 0.222133
    Budget: 0
    Revenue: 0
    Title: Hurlyburly
    Popularity: 0.207296
    Budget: 0
    Revenue: 0
    Title: Sabrina Goes to Rome
    Popularity: 0.164434
    Budget: 0
    Revenue: 0
    Title: Krippendorf's Tribe
    Popularity: 0.14891500000000002
    Budget: 0
    Revenue: 0
    Title: Jerry Seinfeld: I'm Telling You for the Last Time
    Popularity: 0.197432
    Budget: 0
    Revenue: 0
    Title: A Murder of Crows
    Popularity: 0.09377100000000001
    Budget: 0
    Revenue: 0
    Title: Last Night
    Popularity: 0.037177999999999996
    Budget: 0
    Revenue: 0
    Title: Knick Knack
    Popularity: 0.471351
    Budget: 0
    Revenue: 0
    Title: Loverboy
    Popularity: 0.28310100000000005
    Budget: 0
    Revenue: 3960327
    Title: Troop Beverly Hills
    Popularity: 0.254386
    Budget: 0
    Revenue: 0
    Title: The Woman in Black
    Popularity: 0.21707600000000002
    Budget: 0
    Revenue: 0
    Title: Scandal
    Popularity: 0.14877
    Budget: 0
    Revenue: 8800000
    Title: Lonesome Dove
    Popularity: 0.12313199999999999
    Budget: 0
    Revenue: 0
    Title: Goldeneye
    Popularity: 0.094652
    Budget: 0
    Revenue: 0
    Title: For All Mankind
    Popularity: 0.163885
    Budget: 0
    Revenue: 0
    Title: Father of the Bride
    Popularity: 0.387056
    Budget: 0
    Revenue: 89325780
    Title: Ghoulies III: Ghoulies Go to College
    Popularity: 0.31695500000000004
    Budget: 0
    Revenue: 0
    Title: Soapdish
    Popularity: 0.298661
    Budget: 0
    Revenue: 36489888
    Title: Omen IV: The Awakening
    Popularity: 0.251132
    Budget: 0
    Revenue: 0
    Title: Proof
    Popularity: 0.231517
    Budget: 0
    Revenue: 524668
    Title: Lucky Luke
    Popularity: 0.201381
    Budget: 0
    Revenue: 0
    Title: Wedlock
    Popularity: 0.438283
    Budget: 0
    Revenue: 0
    Title: Shakes the Clown
    Popularity: 0.106169
    Budget: 0
    Revenue: 0
    Title: The Hitman
    Popularity: 0.048237
    Budget: 0
    Revenue: 4654288
    Title: Spoorloos
    Popularity: 0.597387
    Budget: 0
    Revenue: 0
    Title: D.O.A.
    Popularity: 0.410654
    Budget: 0
    Revenue: 12706478
    Title: The Bourne Identity
    Popularity: 0.385293
    Budget: 0
    Revenue: 0
    Title: Tin Toy
    Popularity: 0.23651399999999997
    Budget: 0
    Revenue: 0
    Title: Young Einstein
    Popularity: 0.21814499999999998
    Budget: 0
    Revenue: 0
    Title: Big Top Pee-wee
    Popularity: 0.20590999999999998
    Budget: 0
    Revenue: 15122000
    Title: 18 Again!
    Popularity: 0.025511000000000002
    Budget: 0
    Revenue: 0
    Title: Ironweed
    Popularity: 0.333783
    Budget: 0
    Revenue: 0
    Title: The Dead
    Popularity: 0.315932
    Budget: 0
    Revenue: 0
    Title: The Fourth Protocol
    Popularity: 0.263191
    Budget: 0
    Revenue: 0
    Title: The Stepfather
    Popularity: 0.221631
    Budget: 0
    Revenue: 0
    Title: Wanted: Dead or Alive
    Popularity: 0.180267
    Budget: 0
    Revenue: 0
    Title: Beauty and the Beast
    Popularity: 0.17844000000000002
    Budget: 0
    Revenue: 0
    Title: Like Father Like Son
    Popularity: 0.11171099999999999
    Budget: 0
    Revenue: 34377585
    Title: 84 Charing Cross Road
    Popularity: 0.07154500000000001
    Budget: 95
    Revenue: 0
    Title: Scooby-Doo Meets the Boo Brothers
    Popularity: 0.245929
    Budget: 0
    Revenue: 0
    Title: Hellfighters
    Popularity: 0.190352
    Budget: 0
    Revenue: 0
    Title: Ice Station Zebra
    Popularity: 0.092165
    Budget: 0
    Revenue: 0
    Title: The Odessa File
    Popularity: 0.144379
    Budget: 0
    Revenue: 0
    Title: A Woman Under the Influence
    Popularity: 0.075175
    Budget: 0
    Revenue: 0
    Title: Ilsa: She Wolf of the SS
    Popularity: 0.537981
    Budget: 0
    Revenue: 0
    Title: Picnic at Hanging Rock
    Popularity: 0.45031099999999996
    Budget: 0
    Revenue: 0
    Title: Rooster Cogburn
    Popularity: 0.162767
    Budget: 0
    Revenue: 8022000
    Title: Night Moves
    Popularity: 0.017468
    Budget: 0
    Revenue: 0
    Title: Coonskin
    Popularity: 0.032936
    Budget: 0
    Revenue: 0
    Title: The Loneliness of the Long Distance Runner
    Popularity: 0.328639
    Budget: 0
    Revenue: 0
    Title: In Search of the Castaways
    Popularity: 0.322993
    Budget: 0
    Revenue: 0
    Title: Murder Ahoy
    Popularity: 0.37197600000000003
    Budget: 0
    Revenue: 0
    Title: Carry On Cleo
    Popularity: 0.28039000000000003
    Budget: 0
    Revenue: 0
    Title: The Naked Kiss
    Popularity: 0.2196
    Budget: 0
    Revenue: 0
    Title: Il deserto rosso
    Popularity: 0.18526099999999998
    Budget: 0
    Revenue: 0
    Title: Man's Favorite Sport?
    Popularity: 0.122269
    Budget: 0
    Revenue: 0
    Title: The Americanization of Emily
    Popularity: 0.067621
    Budget: 0
    Revenue: 0
    Title: Sunday Bloody Sunday
    Popularity: 0.272856
    Budget: 0
    Revenue: 0
    Title: Countess Dracula
    Popularity: 0.177053
    Budget: 0
    Revenue: 0
    Title: A New Leaf
    Popularity: 0.140996
    Budget: 0
    Revenue: 0
    Title: Dad's Army
    Popularity: 0.11636500000000001
    Budget: 0
    Revenue: 0
    Title: The Abominable Dr. Phibes
    Popularity: 0.07681
    Budget: 0
    Revenue: 0
    Title: Joe Versus the Volcano
    Popularity: 0.53671
    Budget: 0
    Revenue: 39404261
    Title: Repossessed
    Popularity: 0.30946
    Budget: 0
    Revenue: 1382462
    Title: Desperate Hours
    Popularity: 0.285403
    Budget: 0
    Revenue: 0
    Title: Taking Care of Business
    Popularity: 0.257615
    Budget: 0
    Revenue: 0
    Title: White Hunter Black Heart
    Popularity: 0.23528600000000002
    Budget: 0
    Revenue: 0
    Title: Le mari de la coiffeuse
    Popularity: 0.243946
    Budget: 0
    Revenue: 0
    Title: An Angel at My Table
    Popularity: 0.090323
    Budget: 0
    Revenue: 0
    Title: Hamlet
    Popularity: 0.067973
    Budget: 0
    Revenue: 20710451
    Title: The Innocents
    Popularity: 0.296403
    Budget: 0
    Revenue: 0
    Title: The Children's Hour
    Popularity: 0.196467
    Budget: 0
    Revenue: 0
    Title: The Ladies Man
    Popularity: 0.071619
    Budget: 0
    Revenue: 0
    Title: The Unforgiven
    Popularity: 0.42104300000000006
    Budget: 0
    Revenue: 0
    Title: Sergeant Rutledge
    Popularity: 0.269428
    Budget: 0
    Revenue: 0
    Title: Midnight Lace
    Popularity: 0.23257399999999998
    Budget: 0
    Revenue: 0
    Title: The Lost World
    Popularity: 0.14410599999999898
    Budget: 0
    Revenue: 0
    Title: Silver Streak
    Popularity: 0.377579
    Budget: 0
    Revenue: 51079064
    Title: The Killing of a Chinese Bookie
    Popularity: 0.325504
    Budget: 0
    Revenue: 0
    Title: Obsession
    Popularity: 0.569865
    Budget: 0
    Revenue: 0
    Title: Burnt Offerings
    Popularity: 0.194596
    Budget: 0
    Revenue: 0
    Title: Cannonball
    Popularity: 0.126723
    Budget: 0
    Revenue: 0
    Title: Du bi quan wang da po xue di zi
    Popularity: 0.042352999999999995
    Budget: 0
    Revenue: 0
    Title: Joshua Tree
    Popularity: 0.6420399999999991
    Budget: 0
    Revenue: 0
    Title: Another Stakeout
    Popularity: 0.538484
    Budget: 0
    Revenue: 0
    Title: Look Who's Talking Now!
    Popularity: 0.48588000000000003
    Budget: 0
    Revenue: 0
    Title: Babylon 5: The Gathering
    Popularity: 0.41173999999999994
    Budget: 0
    Revenue: 0
    Title: Warlock: The Armageddon
    Popularity: 0.512054
    Budget: 0
    Revenue: 0
    Title: Double, Double, Toil and Trouble
    Popularity: 0.226302
    Budget: 0
    Revenue: 0
    Title: å¤ªæžå¼ ä¸‰ä¸°
    Popularity: 0.265865
    Budget: 0
    Revenue: 0
    Title: Surf Ninjas
    Popularity: 0.41851499999999997
    Budget: 0
    Revenue: 4916135
    Title: The Thief and the Cobbler
    Popularity: 0.0149919999999999
    Budget: 0
    Revenue: 0
    Title: The War Wagon
    Popularity: 0.139647
    Budget: 0
    Revenue: 6000000
    Title: The Gnome-Mobile
    Popularity: 0.094057
    Budget: 0
    Revenue: 0
    Title: Who's That Knocking at My Door
    Popularity: 0.054863
    Budget: 0
    Revenue: 0
    Title: Murder at the Gallop
    Popularity: 0.62852
    Budget: 0
    Revenue: 0
    Title: This Sporting Life
    Popularity: 0.188442
    Budget: 0
    Revenue: 0
    Title: The Servant
    Popularity: 0.12157000000000001
    Budget: 0
    Revenue: 0
    Title: Flight of the Navigator
    Popularity: 0.759795
    Budget: 0
    Revenue: 18564613
    Title: Black Moon Rising
    Popularity: 0.369463
    Budget: 0
    Revenue: 6637565
    Title: Tough Guys
    Popularity: 0.317816
    Budget: 0
    Revenue: 0
    Title: Iron Eagle
    Popularity: 0.253984
    Budget: 0
    Revenue: 0
    Title: Lucas
    Popularity: 0.215644
    Budget: 0
    Revenue: 0
    Title: When the Wind Blows
    Popularity: 0.090923
    Budget: 0
    Revenue: 0
    Title: Breezy
    Popularity: 0.700695
    Budget: 0
    Revenue: 0
    Title: The Long Goodbye
    Popularity: 0.392936
    Budget: 0
    Revenue: 0
    Title: Charlotte's Web
    Popularity: 0.359048
    Budget: 0
    Revenue: 0
    Title: Frankenstein and the Monster from Hell
    Popularity: 0.203942
    Budget: 0
    Revenue: 0
    Title: The Way We Were
    Popularity: 0.385313
    Budget: 0
    Revenue: 45000000
    Title: Sssssss
    Popularity: 0.14507899999999999
    Budget: 0
    Revenue: 0
    Title: Scarecrow
    Popularity: 0.135693
    Budget: 0
    Revenue: 0
    Title: Scrooge
    Popularity: 0.42443000000000003
    Budget: 0
    Revenue: 0
    Title: In Harm's Way
    Popularity: 0.118301
    Budget: 0
    Revenue: 0
    Title: The Hill
    Popularity: 0.24681599999999998
    Budget: 0
    Revenue: 0
    Title: Battle of the Bulge
    Popularity: 0.160842
    Budget: 0
    Revenue: 0
    Title: Hello, Dolly!
    Popularity: 0.39668600000000004
    Budget: 0
    Revenue: 0
    Title: The Computer Wore Tennis Shoes
    Popularity: 0.338357
    Budget: 0
    Revenue: 0
    Title: Carry On Again Doctor
    Popularity: 0.330802
    Budget: 0
    Revenue: 0
    Title: Carry On Camping
    Popularity: 0.021121
    Budget: 0
    Revenue: 0
    Title: Paradise Alley
    Popularity: 0.591799
    Budget: 0
    Revenue: 7185518
    Title: Patrick
    Popularity: 0.184723
    Budget: 0
    Revenue: 0
    Title: Gates of Heaven
    Popularity: 0.13863499999999898
    Budget: 0
    Revenue: 0
    Title: The Cat from Outer Space
    Popularity: 0.072267
    Budget: 0
    Revenue: 0
    Title: Hooper
    Popularity: 0.044675
    Budget: 0
    Revenue: 78000000
    Title: It's the Great Pumpkin, Charlie Brown
    Popularity: 0.276133
    Budget: 0
    Revenue: 0
    Title: Carry On Cowboy
    Popularity: 0.230873
    Budget: 0
    Revenue: 0
    Title: A Big Hand for the Little Lady
    Popularity: 0.22721999999999998
    Budget: 0
    Revenue: 0
    Title: Seconds
    Popularity: 0.089072
    Budget: 0
    Revenue: 0
    Title: Beregis Avtomobilya
    Popularity: 0.0651409999999999
    Budget: 0
    Revenue: 0
    budget: 701
    


```python
def data_loop(category, minimum):
    categorylist = []
    count = 0
    for i in range(1, len(movies_df)):
        if movies_df.iloc[i][category] < minimum:
            movies_df.drop(movies_df.index[i], inplace = False)
            count += 1
    print(category + ": " + str(count))
    return category_list

#popularity_list = data_loop("popularity", 0.01)
budget_list = data_loop("budget", 1000)
   



```

    budget: 2365
    


```python
movies_df.drop[i]
print(len(popularity_list))
budget_list = data_loop("budget", 1000)
revenue_list = data_loop("revenue", 1000)
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    <ipython-input-44-45a2961a6b4c> in <module>()
    ----> 1 movies_df.drop[i]
          2 print(len(popularity_list))
          3 budget_list = data_loop("budget", 1000)
          4 revenue_list = data_loop("revenue", 1000)
    

    TypeError: 'method' object is not subscriptable



```python
%pylab inline
import matplotlib.pyplot as plt
import seaborn as sns
```

    Populating the interactive namespace from numpy and matplotlib
    


```python
# Scatter Plot for budget by revenue to see any trends
# Popularity also scales the plot to see if it is influenced by the budget
fig = plt.figure()
plt.scatter(movies_df['budget'], movies_df['revenue'], s=movies_df['popularity'])
fig.suptitle('All Values - Budget by Revenue', fontsize=20)
plt.xlabel('Budget (100 million)', fontsize=18)
plt.ylabel('Revenue (1 billion)', fontsize=16)
None
```


![png](output_9_0.png)


It seems like there is a general increase in revenue and popularity between 1 (100 million) and 2.5 (250 million) budget value, while also showing an increase popularity value. However, beyond 2.5 (250 million), the trend becomes inconsistent. This inconsistency is not as strong because of the few data points it represents compared to the rest of the scatter plot.


```python
# Changing the scale of the budget on the plot, so the viewer can see the plot more easily
scaled_budgets = movies_df['budget'] / 20000000

# Creating a plot for popularity to revenue based on the entire movie data set
fig = plt.figure()
plt.scatter(movies_df['popularity'], movies_df['revenue'], s=scaled_budgets)
fig.suptitle('All Values - Popularity by Revenue', fontsize=20)
plt.xlabel('Popularity (10 million)', fontsize=18)
plt.ylabel('Revenue (1 billion)', fontsize=16)
None
```


![png](output_11_0.png)


Revenue does not seem very correlated to popularity because the revenue of any movie has values both high and low at various points of popularity. For instance, the popularity value between 25 (250 million) and 30 (300 million) has a revenue value that is less than the popularity value that is beyond 30 (300 million), which is an inconsistent trend.


```python
# Sorting the budget values in movies_df from largest to smallest and using the top 100 budget values along with the corresponding
# index values to get the respective revenue and popularity values 
# (which is essentially gathering the values - budget, revenue, and popularity - that correspond to the same movie)
highest_budgets = movies_df['budget'].sort_values(ascending=False)[0:101]
budgets_index = highest_budgets.index[:]

corresponding_revenue = movies_df['revenue'][budgets_index]
corresponding_popularity = movies_df['popularity'][budgets_index]

# The above values were only to confirm that the line below was accurately displaying the correct corresponding values 
# to each budget variable (The purpose for this is to display a dataframe, while the above code is for plotting values)
budgets_corresponding_values = movies_df.iloc[budgets_index].groupby('original_title')['budget','revenue','popularity']
budgets_corresponding_values.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>budget</th>
      <th>revenue</th>
      <th>popularity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2244</th>
      <td>425000000</td>
      <td>11087569</td>
      <td>0.250540</td>
    </tr>
    <tr>
      <th>3375</th>
      <td>380000000</td>
      <td>1021683000</td>
      <td>4.955130</td>
    </tr>
    <tr>
      <th>7387</th>
      <td>300000000</td>
      <td>961000000</td>
      <td>4.965391</td>
    </tr>
    <tr>
      <th>14</th>
      <td>280000000</td>
      <td>1405035767</td>
      <td>5.944927</td>
    </tr>
    <tr>
      <th>6570</th>
      <td>270000000</td>
      <td>391081192</td>
      <td>1.957331</td>
    </tr>
    <tr>
      <th>4411</th>
      <td>260000000</td>
      <td>284139100</td>
      <td>1.588457</td>
    </tr>
    <tr>
      <th>1929</th>
      <td>260000000</td>
      <td>591794936</td>
      <td>2.865684</td>
    </tr>
    <tr>
      <th>7394</th>
      <td>258000000</td>
      <td>890871626</td>
      <td>2.520912</td>
    </tr>
    <tr>
      <th>5508</th>
      <td>255000000</td>
      <td>89289910</td>
      <td>1.214510</td>
    </tr>
    <tr>
      <th>4367</th>
      <td>250000000</td>
      <td>1017003568</td>
      <td>4.218933</td>
    </tr>
    <tr>
      <th>4363</th>
      <td>250000000</td>
      <td>1081041287</td>
      <td>6.591277</td>
    </tr>
    <tr>
      <th>643</th>
      <td>250000000</td>
      <td>746000000</td>
      <td>6.052479</td>
    </tr>
    <tr>
      <th>5431</th>
      <td>250000000</td>
      <td>958400000</td>
      <td>4.310786</td>
    </tr>
    <tr>
      <th>1923</th>
      <td>250000000</td>
      <td>954305868</td>
      <td>4.840588</td>
    </tr>
    <tr>
      <th>1389</th>
      <td>250000000</td>
      <td>933959197</td>
      <td>5.076472</td>
    </tr>
    <tr>
      <th>634</th>
      <td>250000000</td>
      <td>955119788</td>
      <td>10.174599</td>
    </tr>
    <tr>
      <th>10</th>
      <td>245000000</td>
      <td>880674609</td>
      <td>6.200282</td>
    </tr>
    <tr>
      <th>1386</th>
      <td>237000000</td>
      <td>2781505847</td>
      <td>9.432768</td>
    </tr>
    <tr>
      <th>4381</th>
      <td>225000000</td>
      <td>624026776</td>
      <td>2.592896</td>
    </tr>
    <tr>
      <th>2902</th>
      <td>225000000</td>
      <td>419651413</td>
      <td>1.628345</td>
    </tr>
    <tr>
      <th>5432</th>
      <td>225000000</td>
      <td>662845518</td>
      <td>3.972460</td>
    </tr>
    <tr>
      <th>4361</th>
      <td>220000000</td>
      <td>1519557910</td>
      <td>7.637767</td>
    </tr>
    <tr>
      <th>4370</th>
      <td>215000000</td>
      <td>752215857</td>
      <td>3.702647</td>
    </tr>
    <tr>
      <th>648</th>
      <td>210000000</td>
      <td>245500000</td>
      <td>4.983782</td>
    </tr>
    <tr>
      <th>6883</th>
      <td>210000000</td>
      <td>234360014</td>
      <td>0.157586</td>
    </tr>
    <tr>
      <th>4405</th>
      <td>209000000</td>
      <td>303025485</td>
      <td>1.630455</td>
    </tr>
    <tr>
      <th>6215</th>
      <td>207000000</td>
      <td>550000000</td>
      <td>1.508329</td>
    </tr>
    <tr>
      <th>3</th>
      <td>200000000</td>
      <td>2068178225</td>
      <td>11.173104</td>
    </tr>
    <tr>
      <th>5444</th>
      <td>200000000</td>
      <td>743559607</td>
      <td>2.643496</td>
    </tr>
    <tr>
      <th>3393</th>
      <td>200000000</td>
      <td>559852396</td>
      <td>2.454226</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7448</th>
      <td>175000000</td>
      <td>173000000</td>
      <td>1.109374</td>
    </tr>
    <tr>
      <th>4372</th>
      <td>170000000</td>
      <td>396600000</td>
      <td>3.335603</td>
    </tr>
    <tr>
      <th>3418</th>
      <td>170000000</td>
      <td>185770160</td>
      <td>1.488615</td>
    </tr>
    <tr>
      <th>2434</th>
      <td>170000000</td>
      <td>222104681</td>
      <td>1.221973</td>
    </tr>
    <tr>
      <th>651</th>
      <td>170000000</td>
      <td>708200000</td>
      <td>4.452507</td>
    </tr>
    <tr>
      <th>5424</th>
      <td>170000000</td>
      <td>479765000</td>
      <td>5.111900</td>
    </tr>
    <tr>
      <th>1928</th>
      <td>170000000</td>
      <td>400062763</td>
      <td>2.911727</td>
    </tr>
    <tr>
      <th>630</th>
      <td>170000000</td>
      <td>773312399</td>
      <td>14.311205</td>
    </tr>
    <tr>
      <th>631</th>
      <td>170000000</td>
      <td>714766572</td>
      <td>12.971027</td>
    </tr>
    <tr>
      <th>6976</th>
      <td>165000000</td>
      <td>305875730</td>
      <td>2.241935</td>
    </tr>
    <tr>
      <th>1949</th>
      <td>165000000</td>
      <td>752600867</td>
      <td>1.820934</td>
    </tr>
    <tr>
      <th>1926</th>
      <td>165000000</td>
      <td>494878759</td>
      <td>3.560424</td>
    </tr>
    <tr>
      <th>629</th>
      <td>165000000</td>
      <td>621752480</td>
      <td>24.949134</td>
    </tr>
    <tr>
      <th>4379</th>
      <td>165000000</td>
      <td>471222889</td>
      <td>2.858742</td>
    </tr>
    <tr>
      <th>635</th>
      <td>165000000</td>
      <td>652105443</td>
      <td>8.691294</td>
    </tr>
    <tr>
      <th>3412</th>
      <td>163000000</td>
      <td>174822325</td>
      <td>1.640256</td>
    </tr>
    <tr>
      <th>5257</th>
      <td>160000000</td>
      <td>164508066</td>
      <td>1.172353</td>
    </tr>
    <tr>
      <th>659</th>
      <td>160000000</td>
      <td>529076069</td>
      <td>3.689601</td>
    </tr>
    <tr>
      <th>6643</th>
      <td>160000000</td>
      <td>181674817</td>
      <td>0.826011</td>
    </tr>
    <tr>
      <th>5650</th>
      <td>160000000</td>
      <td>788679850</td>
      <td>0.522347</td>
    </tr>
    <tr>
      <th>3801</th>
      <td>160000000</td>
      <td>344420111</td>
      <td>0.164515</td>
    </tr>
    <tr>
      <th>7411</th>
      <td>160000000</td>
      <td>798958165</td>
      <td>1.862295</td>
    </tr>
    <tr>
      <th>1919</th>
      <td>160000000</td>
      <td>825500000</td>
      <td>9.363643</td>
    </tr>
    <tr>
      <th>19</th>
      <td>160000000</td>
      <td>650523427</td>
      <td>5.476958</td>
    </tr>
    <tr>
      <th>6974</th>
      <td>160000000</td>
      <td>300257475</td>
      <td>2.499507</td>
    </tr>
    <tr>
      <th>2435</th>
      <td>160000000</td>
      <td>61698899</td>
      <td>1.189386</td>
    </tr>
    <tr>
      <th>6</th>
      <td>155000000</td>
      <td>440603537</td>
      <td>8.654359</td>
    </tr>
    <tr>
      <th>1934</th>
      <td>155000000</td>
      <td>415686217</td>
      <td>2.245241</td>
    </tr>
    <tr>
      <th>7009</th>
      <td>155000000</td>
      <td>167298192</td>
      <td>1.319068</td>
    </tr>
    <tr>
      <th>6977</th>
      <td>150000000</td>
      <td>919838758</td>
      <td>2.191033</td>
    </tr>
  </tbody>
</table>
<p>101 rows × 3 columns</p>
</div>




```python
# Scaling the popularity value to be more visible on the scatter plot
scaled_popularity = corresponding_popularity * 3

# Creating a plot based on the three spliced sets of data above for the highest budget values with their corresponding revenue
# and popularity values
fig = plt.figure()
plt.scatter(highest_budgets, corresponding_revenue, s=scaled_popularity)
fig.suptitle('Highest Budget Values - Budget by Revenue', fontsize=20)
plt.xlabel('Budget (100 million)', fontsize=18)
plt.ylabel('Revenue (1 billion)', fontsize=16)
None
```


![png](output_14_0.png)


In this smaller set of data (top 100 budget values) there seems to be a similar trend to the last plot, where there was a general
increase in revenue as the budget value increased. The popularity, however, didn't seem to follow the previous plot trend where it increased along with revenue. In this plot it seemed to be at its highest value between 0.5 (500 million) and 1.5 (1.5 billion) revenue value, but it was very inconsistent out of that range.


```python
# Scaling the budget values to allow the viewer to see the points on the plot
scaled_budgets = highest_budgets / 20000000

# Creating a plot based on the new smaller data (highest budget values) set to see the influence of popularity to revenue
fig = plt.figure()
plt.scatter(corresponding_popularity, corresponding_revenue, s=scaled_budgets)
fig.suptitle('Highest Budget Values - Popularity by Revenue', fontsize=20)
plt.xlabel('Popularity (10 million)', fontsize=18)
plt.ylabel('Revenue (1 billion)', fontsize=16)
None
```


![png](output_16_0.png)


The popularity value seems to have a direct relationship with revenue for the highest budget values. The trend shows to be an increase in popularity brings an increase of revenue.

# Conclusion:

My findings seem to support the general proportional relationship between budget price and the revenue value of a movie. The smaller data sets contrived from the top 100 highest budget values and their corresponding revenue and popularity values brought a different perspective on my concluding trends. The large data set presents trends, however, they are not supported by enough plot points for me to be confident to say the trends are accurate and active in the movie industry. Although my findings didn't bring very strong trends, they did open up new thoughts and directions for me to explore to create more unique conclusions. This project opened a door to a variety of connections in not just this movie data set, but generally the concept of data analysis.
